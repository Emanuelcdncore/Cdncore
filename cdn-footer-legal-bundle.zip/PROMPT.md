# Apply CDN Footer + Legal Pages To Target Service

You are getting a bundle extracted from `apps/cdncore` (Next.js 16 App Router, standalone output, Inter/sans-serif, dark theme #131115, purple/pink accent #8B5CF6 → #EC4899). Goal: replicate the **same Footer** (with mandatory Portuguese funding banners) and the **three legal pages** (Privacy, Terms, Cookies) inside another Next.js app in the same monorepo. Keep visual + structural parity with cdncore. Do not re-design.

## Bundle contents

```
components/
  Footer.tsx              ← main footer (uses CustomMap + 3 image assets + BASE_PATH env)
  CustomMap.tsx           ← Leaflet map embedded in footer (loaded from unpkg CDN, no npm dep needed)
  PrivacyPolicy.tsx
  CookiesPolicy.tsx
  TermsOfService.tsx
  css/
    Footer.css
    LegalPages.css
app/
  privacy-policy/page.tsx
  terms-of-service/page.tsx
  cookies-policy/page.tsx
public/
  footer.webp                       ← PRR / República Portuguesa / União Europeia bar (MANDATORY, do not edit)
  assets/footer-iefp.png            ← IEFP / Pessoas 2030 / Portugal 2030 bar (MANDATORY, do not edit)
  assets/logos/CDNCORE-03_footer.png ← REPLACE with target service's footer logo
```

## Steps

1. **Drop files into target app** preserving paths (`apps/<target>/components/...`, `apps/<target>/app/...`, `apps/<target>/public/...`). Merge, do not overwrite unrelated files.

2. **Replace footer logo**. `public/assets/logos/CDNCORE-03_footer.png` is cdncore-branded. Swap with target's footer logotype (same approximate aspect, ~400×230). Update the `<Image src=...>` path + `alt` in `Footer.tsx`.

3. **Keep both Portuguese funding banners as-is**. `footer.webp` (PRR) and `assets/footer-iefp.png` (IEFP) are legal compliance assets for EU/PT funding programs. Do not crop, recolor, or remove. Keep at the rendered heights from `Footer.tsx` (40px and 130px).

4. **Update footer link sections** in `Footer.tsx` to match target service:
   - `SERVICES` column: replace anchors (`#cybersecurity`, `#ai-solutions`, designers link) with target's actual section IDs / URLs.
   - `COMPANY` column: cdncore points to `/commitments` and its anchors. If target has no equivalent route, replace with target's About / Mission / Team routes, or remove the column.
   - `LEGAL` column: keep as-is (`/privacy-policy`, `/terms-of-service`, `/cookies-policy`).
   - `CONTACTS` column: replace address + phone with target's. Currently hardcoded: Parkurbis, Covilhã, +351 275 959 168.
   - Copyright string: replace `CDNCORE - AI Agent & Drone Services` with target name + tagline.

5. **`/estagios-profissionais` link**: footer wraps the IEFP banner in `<a href="${bp}/estagios-profissionais">`. That route only exists on cdncore (PDF + page). On target service either:
   - Create the same route, OR
   - Remove the `<a>` wrapper and render the IEFP image alone, OR
   - Point the link to cdncore's full URL (`https://cdncore.eu/estagios-profissionais`).

6. **`CustomMap.tsx`**:
   - Loads Leaflet from `unpkg.com/leaflet@1.9.4` at runtime — no npm dependency required.
   - Hardcoded coordinates `40.22831908063358, -7.49888183428806` (Parkurbis Covilhã) and popup text. Update both for target's address.
   - References `${bp}/assets/images/Location_Pin_Core.png` for the marker. Either copy that asset from cdncore (`apps/cdncore/public/assets/images/Location_Pin_Core.png`) or swap for target's pin and update the path.

7. **`BASE_PATH` env var**: monorepo convention — empty in dev (subdomain routing), set in prod (path routing). All asset paths in Footer / CustomMap use `${bp}` prefix. Keep that pattern. No code change needed if target already follows the convention.

8. **Legal page bodies**: `PrivacyPolicy.tsx`, `CookiesPolicy.tsx`, `TermsOfService.tsx` contain CDNCore-specific copy:
   - Brand name `CDNCore` / `CDNCORE` → replace with target brand throughout.
   - Email addresses `privacy@cdncore.com`, `legal@cdncore.com` → replace with target's.
   - "Last updated: March 2026" date → keep or update.
   - Address "Lisbon, Portugal" in Privacy Policy → replace with target's.
   - "CDNCore provides technology consulting, cybersecurity solutions, AI development..." in Terms § 2 → rewrite to match target's actual services.
   - Governing law (Portugal) → keep unless target is in different jurisdiction.

9. **Page route metadata**: each `app/<legal>/page.tsx` has `metadata.title` + `metadata.description` mentioning CDNCore. Update both, plus `alternates.canonical`.

10. **CSS**: `Footer.css` and `LegalPages.css` use cdncore's purple/pink palette (`#8B5CF6`, `#EC4899`, `#A78BFA`) and dark bg (`#131115`). If target uses a different palette, replace those hex values consistently across both files. Keep layout/spacing/breakpoints.

11. **Imports**: components use `@/components/...` path alias. Verify target's `tsconfig.json` has the same alias; otherwise rewrite imports.

12. **`'use client'` directives**: kept on Footer, CustomMap, and all three legal components because of `useEffect` (CustomMap), `onClick` (Footer), `Link`+icons (legal pages). Do not remove.

13. **Verify build**: `npm run build` from monorepo root. Watch for missing assets (paths case-sensitive on Linux containers) and missing `lucide-react` dep (used by legal pages — add if absent).

## Acceptance

- `/privacy-policy`, `/terms-of-service`, `/cookies-policy` render with target branding, target contact info, target's services described in Terms § 2.
- Footer renders on every page where it's mounted; both PT funding banners visible at correct heights; map shows target location with custom pin; copyright shows target name and current year.
- `npm run build` passes for the target app.
- No leftover `CDNCORE` / `CDNCore` / `cdncore.com` / `cdncore.eu` strings in target's copied files (`grep -ri cdncore apps/<target>/{components,app}` returns nothing from the new files).

## Out of scope

Do not touch unrelated routes, layouts, or global CSS in the target app. Do not add npm dependencies beyond `lucide-react` (and only if not already installed). Do not modify the funding banner images.
